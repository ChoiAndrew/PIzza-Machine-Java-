package shapes;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

/*
 * 
 * Andrew Choi
 * 
 * CSS 143 Circle class extends shape
 * 
 * June 10 2019
 * 
 * 
 * The circle class is a class we previously made
 * in our homework and it extends from shape and
 * implements clonebale. The circle class has a x,y 
 * cordinate, a radius and a color. In this class
 * we draw the Circle based on the given dimensions
 * and cordinates. 
 */

public class Circle extends Shape implements Cloneable {

	
	  private double radius;
	  private int x,y;
	  private Color col;

	  /*
	   * No arg constuctor that we will use
	   * in the pizza class to generate the 
	   * base of the pizza
	   */
	  public Circle()
	  {
		  super();
		  setRadius(8);
	  }
	  /*
	   * The constructor for circle class that takes in a 
	   * x,y cordinate , the radius and the color. It sets 
	   * the cordinates and color by calling the super
	   * function and sets the radius to this class
	   */
		public Circle(int xCor, int yCor, double radius, Color color) 
		{
			//Using to super to call the parent constructor
			super(xCor, yCor,color);
			setRadius(radius);
		}
		
       /*
        * This method takes in a graphics object
        * and draws our shape based on the 
        * codrinates, 
        */
		public void draw( Graphics g)
		{
			Graphics2D draw = (Graphics2D) g;
			 g.drawOval(getX(),getY(),getX(),getY());
			
		}

        /*
         * The method getRadius returns
         * the radius of the circle
         */
		public double getRadius() {
			return radius;
		}

		/*
		 * setRadius sets the radius for the 
		 * Circle
		 */
		public void setRadius(double radius) 
		{
			if(radius > 0)
			{
				//Checking invariants
			this.radius = radius;
			}
			else
			{
				System.out.println("Not a valud radius");
			}
		}

		/*
		 * This method is a getter for the 
		 * color object to acess the color
		 */
		public Color getColor() {
			return col;
		}

		/*
		 * This method is used as a setter 
		 * for the color and sets the instance
		 * variable col to the color
		 * taken in.
		 */
		public void setColor(Color color) {
			this.col = color;
		}

		/*
		 * The overriden clone method clones 
		 * the instance of this class and returns 
		 * a new circle with the cordinates, dimensions
		 * and color.
		 */
	@Override
	public Object clone() 
	{
		return new Circle (getX(), getY(), getRadius(), getColor());
	}

	/*
	 * The getArea method as it sounds is a 
	 * getter method for area. For a circle 
	 * we follow the formula pi *r^2. This method
	 * is overriden from the parent class. 
	 */
	@Override
	public double getArea() {
		double rad = 0;
		rad = (this.radius * this.radius * Math.PI);
		return rad;
		
	}
	


	
}
