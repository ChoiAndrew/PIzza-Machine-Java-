package shapes;

import java.awt.Color;
import java.awt.Graphics;

/*
 * Andrew Choi
 * 
 * CSS 143 Shape class implements CLoneable
 * 
 * June 10 2019
 * 
 * 
 * This class is the parent class for both
 * the square and a circle and represents
 * a generic shape. It contains a x and y
 * cordinate for the shape and also a color. It has
 *  a couple constuctors and a copy constructor to 
 *  avoid privacy leaks.Has getters and setters for
 *  all instance variables. 
 */
public abstract class Shape implements Cloneable {
	private int x=0,y=0;
	private Color color = null;
		
	/*
	 * Clone method to override Cloneables
	 * clone method. This class is made abstract so it 
	 * can be overrieden in the square and 
	 * circle class. 
	 */
	@Override
	public abstract Object clone();
	
	/*
	 * empty no arg constructor that may be
	 * used later on in this assignemnt
	 */
	public Shape(){}
	
	/*
	 * Overload constructor for the shape class
	 * that takes in a x and y cordinate and also
	 *  a color to represent the shape
	 */
	public Shape(int xCord, int yCord, Color col)
	{
		setX(xCord);
		setY(yCord);
		setColor(col);
	}
	
   /*
    * A copy constructor for shape to 
    * avoid potential privacy leaks by 
    * making a new instance when called
    */
	public Shape(Shape other) {
		setX(other.x);
		setY(other.y);
	}
	
	/*
	 * The getter for x returns 
	 * the value of the x instance 
	 * variable in this class
	 */
	public int getX() {
		return x;
	}

	/*
	 * The setX method sets the instance
	 * variable x  to the integer taken in.
	 */
	public void setX(int xC) {
		this.x = xC;
	}
/*
 * The getY method returns the value of
 * the y instance variable inside this 
 * class. 
 */
	public int getY() {
		return y;
	}

	/*
	 * The setter for Y takes in a integer 
	 * value and sets the y instance variable 
	 * for this class equal to it
	 */
	public void setY(int yC) {
		this.y = yC;
	}
	//public abstract void draw(Graphics g);
	/*
	 * The getArea method is made abstract 
	 * so that we can override it in both the 
	 * square and circle classes. 
	 */
	public abstract double getArea();

	/*
	 * The getColor method returns
	 * the color value inside the color 
	 * variable for this class
	 */
	public Color getColor() {
		return color;
	}
   /*
    * The setColor method takes in a color
    * and sets this classes instance variable
    * color to that value
    */
	public void setColor(Color color) {
		this.color = color;
	}
	
}
