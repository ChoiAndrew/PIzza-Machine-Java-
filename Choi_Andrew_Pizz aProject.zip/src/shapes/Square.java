
package shapes;
import java.awt.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
/*
 * Andrew Choi
 * 
 * CSS 143 Square class entends shape
 * 
 * June 10 2019
 * 
 * This class represents a square object that extends
 * from the shape parent class and also implements
 * cloneable interface
 */
public class Square extends Shape implements Cloneable
{

  private int x;
  private int y;
  private double length;
  private String shape = "[ ]";
  private Color col;

  /*
   * EMpty no arg constructor for Square class
   * that sets the side length for the square
   * pizza
   */
  public Square()
  {
	  super();
	  setLength(8);
  }
  /*
   * Constructor for the square class that takes
   * in and sets the x cordinate, y cordinate, length
   * and color of the square by calling super
   */
	public Square(int nx, int ny, int length, Color color) 
	{
		super(nx, ny, color);
		setLength(length);
		
	}
	
/*
 * Draw method that we probably wont use but
 * it draws the square by taking in a graphics 
 * object based on its dimensions, location and
 * color
 */
	public void draw( Graphics g)
	{
		int tempLength = (int)getLength();
		g.draw3DRect(getX(),getY(),tempLength,tempLength,true);
        
	}
/*
 * The getLength method returns the 
 * length of the square.
 */
	public double getLength() {
		return length;
	}

/*
 * The setLength method takes in a 
 * integer and sents the instance variable 
 * length to the given integer value.
 */
	public void setLength(int length) 
	{
		this.length = length;
	}
	
	/*
	 * The clone method is overriden here and
	 * creates a new instance of the square with 
	 * the same dimensions, location and color
	 */
	public Object clone()
	{
	    	int castedLength = (int) getLength();
			return new Square(getX(), getY(), castedLength,getColor());
	}

	/*
	 * The getArea method is overriden here and 
	 * returns a double amount of the side length 
	 * * 2 since it is a square the formula is side 
	 * length * 2. 
	 */
	@Override
	public double getArea() {
		
		double area = 0;
		area = (this.length * 2);
		return area;
	}
}

