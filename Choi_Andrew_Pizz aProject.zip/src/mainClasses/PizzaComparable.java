package mainClasses;
/*
 * Andrew Choi
 * 
 * CSS 143 PizzaCoparable extnds Comparable
 * 
 * June 10 2019
 */
public interface PizzaComparable extends Comparable {  //Example of interface inheritance
	
	@Override
	//compareTo method used to compare objects via price
	public int compareTo(Object obj); 	 		//a.k.a compareToByPrice
	//compareTo method that compares Objects via size
	public int compareToBySize(Object obj); 		//a.k.a. compareToByAreaLeft
	//Compares method to objects via calories
	public int compareToByCalories(Object obj);	
	
}
