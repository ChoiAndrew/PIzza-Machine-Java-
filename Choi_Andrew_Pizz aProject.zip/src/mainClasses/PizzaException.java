package mainClasses;

/*
 * @author Andrew Choi
 * 
 * CSS 143 Pizza Exception class
 * 
 * June 10 2019
 * 
 * In the PizzaException class we are extending from
 * javas RuntimeException and creating out own
 * custom exception. This class is relatively short 
 * and only contains a few lines of code. The reason 
 * for creating out own custom exception is so that 
 * we can use this in our Pizza class to see what problems 
 * we have when we print to console. 
 */
public class PizzaException  extends RuntimeException
{
	/*
	 * Empty no argument constructor. Calls parent class
	 * using super funtion
	 */
     PizzaException()
     {
    	 super();
     }
     
     /*
      * Overload constructor that takes in a String.
      * Calls parent class using super
      */
     PizzaException(String message)
     {
    	 super(message);
     }
}