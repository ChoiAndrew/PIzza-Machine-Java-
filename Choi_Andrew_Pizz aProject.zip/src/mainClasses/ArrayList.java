package mainClasses;

/**
 * Andrew Choi
 * 
 * CSS 143 ArrayList class extends Comparable
 * 
 * June 10 2019
 * 
 * This class behaves like a java built in array list. The class contains
 * an array of objects (TBA) and a counter to keep track of the number
 * of elements inside the array. There are several methods that help the
 * array become an array list. An arraylist should be able to resize itself and
 * shift elements over either to add or remove objects. In this class there is an
 * add method, remove method, resize method, size method, isEmoty method, 
 * index of method, two methods to shift left and right, equals method and 
 * to String method.
 */

public class ArrayList<TBA extends Comparable> {


	//Instance variables for this class is an array and a counter
	// to keep track of the number of elements.
	private Object[] arr = new Object[10];
	private int count = 0;

	//This method behaves like a java built in function
	// for the array list. It inserts an object at the 
	//specified index.
	public void add(TBA obj, int index) {
	  //Resizes array if the array is full
		TBA temp = obj;
		if(index < 0)
			throw new PizzaException("Cant be in negative index");
		
		if(temp == null)
			throw new PizzaException("Null Object");

	while(count >=  arr.length || index > arr.length)
	   {
		   resize();
	   }
		count++;
		//Shift all elements to the right after the index
		shiftRight(index);
		arr[index] = temp;
	}

	/*
	 * The remove method removes the object at the
	 * specified index and returns it. Checks invariants
	 * if index is out of bounds
	 */
	public TBA remove(int index)
	{
		if(index > count)
			throw new PizzaException("Index out of bounds");
		
		if(arr[index] == null)
			throw new PizzaException("Value is null");
		
		TBA retVal = (TBA)arr[index];
		//Shift left to replace empty space
		shiftLeft(index);
		//Decrement count
		count--;
		return retVal;
		}
		
	/*
	 * The purpose of the resize method is to be called
	 * in the add method for when the array is full. 
	 */
	private void resize() {
		//Add double the amount of spaces
		Object[] arr2 = new Object[arr.length * 2];
		for (int i = 0; i < arr.length; i++) {
			arr2[i] = arr[i];
		}
		arr = arr2;
	}

	/*
	 * This method is basically a getter for count,
	 * where it returns the number of elements in
	 * the array. 
	 */
	public int size() {
		
		return count;
	}

	/*
	 * toString method for the ArrayList class
	 * that returns a string of the Objects. 
	 */
	public String toString() {
		
		String retVal = "";
		
		for(int i = 0; i < arr.length; i++)
		{
			if((TBA)arr[i] != null)
			retVal += arr[i] + "\n";
		}
		return retVal;
	}

	/*
	 * Checks to see if the array arr is
	 * empty or not. 
	 */
	public boolean isEmpty()
	{
		return count == 0;
	}

	/*
	 * This method returns the index of where
	 * the object is stored at. 
	 */
	public int indexOf(Object target) {
		int index = -1;
		if((TBA)target == null)
			throw new PizzaException("Null input");
		
		//Returns -1 if object was not found
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == target) {
				index = i;
				break;
			}
		}
		return index;

	}
    /*
     * This method shifts the array to 
     * the left by one spot, starting at a
     * specified index. 
     */
	public void shiftLeft(int start) {
		for (int i = start; i < count - 1; i++) {
			arr[i] = (TBA) arr[i + 1];
		}

	}

	/*
	 * This method shifts everything to the right 
	 * after the given index to make room to add
	 * values. 
	 */
	public void shiftRight(int end) {
		for (int i = count - 2; i >= end; i--) {
			arr[i + 1] = arr[i];

		}
		
		
	}
	
	
		/*
		 *This is the overridden method for the equals
		 *method. It compares the two array list 
		 */
		public boolean equals(Object other)
		{
			boolean sameArrayList = false; 
			
			if((TBA)other == null)
				return false;
			if (!((TBA)other instanceof ArrayList))
				return false;
			ArrayList castedObject  = (ArrayList) (TBA)other;
			if(castedObject.size() != size())
				return false;
			for(int i = 0; i< count; i++)
			{
				if((TBA)arr[i] == (TBA)castedObject.arr[i])
					sameArrayList = true;
				else
				return false;
			}
			return sameArrayList;
		}
	
		/*
		 * The get method returns the value
		 * of the array at the corresponding 
		 * index and cast it to a TBA.
		 */
     public TBA get(int idx)
     {if( idx < 0)
    	 throw new PizzaException("Index out of bounds");
     
    	 return (TBA) arr[idx];
     }
     
     /*
      * The swap method where I take in two 
      * indexed and swap the data at those 
      * given indexes.
      */
     public void swap(int idx1, int idx2)
     {
    	 if(idx1 < 0 || idx2 < 0 || idx1 == idx2)
    	 {
    		 System.out.println("Im am here");
    		 throw new PizzaException("Values not valid");
    	 }
    	 TBA tempTBA =(TBA) arr[idx1];
    	 arr[idx1] =idx2;
    	 arr[idx2] = tempTBA;
    	
     }

	public Object objectAt(int mid) 
	{
		if(mid < arr.length)
		return arr[mid];
		else 
			return null;
	}
	

}

