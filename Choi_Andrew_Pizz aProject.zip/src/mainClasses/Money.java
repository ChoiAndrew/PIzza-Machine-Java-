package mainClasses;
/**
* Andrew Choi
* 
* CSS 143 Money class
* 
* June 10 2019
*/

/*
    This class represents money and contains 
    both dollars and cents. This class contains 
    several add, remove methods and constructors.
    When the cents is over 100 I make sure to
    account for it and increase my dollar amount accordingly.
    There is also a copy constructor for the class to help
    prevent privacy leaks. The money class represents
    the price of ingredients and the pizza as a whole. 
*/
public class Money implements Comparable{

	  private int dollars;
	  private int cents;
	   
	  /*
	   * Empty no arg constructor that will be
	   * later used in the project
	   */
	  public Money()
	  {
		  
	  }
	 
	  /*
	   * This is the constructor for the Money class
	   * that only takes in the dollar amount and 
	   * calls the setter to set the value;
	   */
	  public Money(int dol)
	  {
		  setDollar(dol);
	  }
	   
	  /*
	   * This is the overload constructor for 
	   * the class that takes in the dollar amount 
	   * and cent amount and sets it.
	   */
	  public Money(int dol, int cent)
	  {
		  setDollar(dol);
		  setCent(cent);
		  
	  }
	  
	  /*
	   * This is the other overload constructor that
	   * acts as a copy constructor to prevent 
	   * privacy leaks.
	   */
	  public Money(Money other)
	  {
		setDollar(other.dollars);
		 setCent(other.cents);
	  }

	  public int compareTo(Object obj) 
	  {
		  if(obj == null)
				throw new RuntimeException("Object null");
			if(!(obj instanceof Money))
				throw new RuntimeException("Object not Money");
			Money that = (Money) obj;
			double temp=  getMoney() - that.getMoney();
			if(temp == 0)
				return 0;
			else if (temp < 0)
				return -1;
			else
				return 1;
		}
	  
	  /*
	   * getMoney is a getter for money that 
	   * returns the final amount for the class.
	   */
	public double getMoney() 
	{
		return this.dollars + (this.cents * 0.01);
	}

	/*
	 * setMoney takes in a dollar and cent amount and 
	 * sets it to the total amount of money.
	 */
	public void setMoney(int dol, int cent) {
		setDollar(dol);
		setCent(cent);
	}

	/*
	 * getDollar returns an integer of the dollar
	 * amount dor the class.
	 */
	public int getDollar() {
		return dollars;
	}

	/*
	 * setDollars takes in the amount of dollars
	 * and sets it to the instance variable.
	 */
	public void setDollar(int dollars)
	{
		if(dollars > 0)
		this.dollars = dollars;
		
	}

	/*
	 * getCents returns an integer of  the cents 
	 * amount forthe class.
	 */
	public int getCent() {
		return cents;
	}

	/*
	 * setCents takes in a integer of cents and
	 * sets it to the instance variable. Checks to see
	 * if cent amount is over 99 and adds to dollars 
	 * accordingly
	 */
	public void setCent(int cents) {
		if(cents < 0)
		{
			System.out.println("Not a valid amount of cents");
		}
		else if(cents  >= 100) 
		{
			int extra = cents/100;
			cents = cents - (extra*100);
			add(extra);
			this.cents = cents;
		}
		else
		this.cents = cents;
	}

	/*
	 * This is the add method for the class where
	 * it takes in a money object and adds that amount to
	 * our classes amount. 
	 */
	public void add(Money other)
	{
		this.dollars += other.getDollar();
		this.cents += other.getCent();
	}
	
	/*
	 * This is the overload method for add where it 
	 * takes in the dollar amount and adds it to the 
	 * final amount.
	 */
	public void add(int dol)
	{
		if(dol >= 0)
		{
		this.dollars += dol;
		}
	}
	

	/*
	 * This is the overload method for add where it 
	 * takes in the dollar amount and the cent amount
	 *  and adds it to the final amount.
	 */
	public void add(int dol, int cent)
	{
		if(dol>= 0)
		{
		this.dollars += dol;
		setCent(cent);
		}
		else
		{
			System.out.println( "Not a valid amount of dollars");
		}
	}
	
	/*
	 * Equals method that check to see if the object
	 * that the method id taking in contains the same 
	 * amount as our current amount.
	 * 
	 */
	public boolean equals(Object obj)
	{
		//null check
		if(obj == null)
		{
			throw new RuntimeException("Null Object");
		}
		//Instance check
		if(!(obj instanceof Money))
		{
			throw new RuntimeException("Not a money objecy");
		}
		boolean sameMoney = false;
		//Casting object 
		Money cast = (Money)obj;
			if(getMoney() == cast.getMoney())
			{
				sameMoney = true;
			}

		return sameMoney;
	}
	
	/*
	 * The toString method for out Money class
	 * that returns the total amount of money
	 * for our pizza ingredients and the pizza;
	 * 
	 */
	public String toString()
	{
		String retVal;
		retVal = "Amount:  $" + getMoney();
		return retVal;
	}
	
}

