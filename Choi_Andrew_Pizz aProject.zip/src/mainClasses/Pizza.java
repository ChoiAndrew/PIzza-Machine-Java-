package mainClasses;
import java.text.DecimalFormat;
import java.util.Random;

import shapes.Circle;
import shapes.Shape;
import shapes.Square;
import timeStamp.Date;
import timeStamp.TimeStamp;
import ingredients.Alfredo;
import ingredients.Goat;
import ingredients.Ingredient;
import ingredients.Marinara;
import ingredients.Mozerella;
import ingredients.Olive;
import ingredients.Pepper;
import ingredients.Pepperoni;
import ingredients.Sausage;

/*
 * Andrew Choi 
 * 
 * CSS 143 Pizza class implemetns PizzaComparable
 * 
 * June 10 2019
 * 
 * This class is the "bread and butter" of this project. This class
 * contains a pizza object and almost uses every single class we
 * made so far including the ingredients, shapes and main 
 * classes. The data items hold a cost, calorie count, shape
 * fraction, ingredient count and a string for the shape. It also 
 * contains an arrayList just for the the ingredients. The purpose
 * of this projects was to let us practice several of the topics we have
 * learned this quarter and combines several of our homeworks. By
 *  wokring on this project it allowed me to see how each individual class
 *  is like a puzzle piece and once you put it all together, you get a fully
 *  functioning pizza machine. 
 * 
 */
  public class Pizza implements PizzaComparable{
  	
   private ArrayList<Ingredient> ingredientList = new ArrayList<Ingredient>();
	//sum	of	all	ingredients’	calories
   private int calorieCount = 0;
   private Money cost = new Money(6);
   private Shape pizzaShape;
   private Fraction myPizza = new Fraction();
   private int ingredientCount = 0;
   private String tempShape;
   private TimeStamp dateMade;

	
   /*
    * The method is commonly used throughout
    * the code because it generates a pizza with 
    * a random base, meat, cheese, shape and 
    * Sauce. It also sets the timeStamp for when the 
    * pizza was made
    */
   public Pizza() 
   { 
       Random randNum = new Random();
       Ingredient sauce;
       Ingredient cheese;
       Ingredient meat;
       Ingredient vegetable;
       
       if(randNum.nextInt(10) % 2 == 0)
       {
    	   this.pizzaShape = new Circle();
           tempShape = "Circular";
       }
       else
       {
    	   this.pizzaShape = new Square();
               tempShape = "Square";
       }
       
       if(randNum.nextInt(10) % 2 == 0)
       {
    	   sauce = new Marinara();
           addIngredient(sauce);
       }
       else
       {
    	   pizzaShape = new Circle();
           sauce = new Alfredo();
           addIngredient(sauce);
       }
       
       if(randNum.nextInt(10) % 2 == 0)
       {
    	   meat = new Sausage();
           addIngredient(meat);
       }
       else
       {
           meat = new Pepperoni();
           addIngredient(meat);
       }
       
       if(randNum.nextInt(10) % 2 == 0)
       {
    	  vegetable = new Olive();
           addIngredient(vegetable);
       }
       else
       {
           vegetable = new Pepper();
           addIngredient(vegetable);
       }
       
       dateMade= new TimeStamp( PizzaManager.getCurrentDate(), PizzaManager.getCurrentTime() );
   }

   /*
    * The getRemainingFraction method returns
    * a newFraction of myPizza since the 
    * fraction class is immutable
    */
	public Fraction getRemainingFraction()
	{
		return new Fraction(myPizza);
	}
	
	/*
	 * Set remaining sets the pizza value
	 * by taking in a Fraction oblect and 
	 * assigning it to out fraction
	 */
	public void setRemaining(Fraction fra)
	{
		 this. myPizza = new Fraction(fra);
	}
	
	/*
	 * getArea returns the area of the remaining
	 * pizza by calling our fraction and 
	 * multiplying it by the area
	 */
	public double getRemainingArea()
	{
		double temp =  (double)myPizza.getNumerator()/(double)myPizza.getDenominator();
		return pizzaShape.getArea() * temp;
	}
	
	/*
	 * getCalories returns  the 
	 * calorieCount added up with all the
	 * ingredients. 
	 */
	public int getCalories()
	{
		return calorieCount;
	}
	
	/*
	 * tthe getCost method gets the anount for
	 * our pizza and returns it as a double. 
	 */
	public double getCost()
	{
		//the instructions said to return an int
		 // but that didnt make sense. 
		return cost.getMoney();
	}
	
	/*
	 * addIngredient method takes in a 
	 * Ingredient object and adds it to the pizza.
	 * We also have to account for cost 
	 * and calories. 
	 */
	public void addIngredient(Ingredient	ingr)
	{
		if(ingr == null)
		{
		throw new PizzaException("Ingredient is null");
		}
		ingredientList.add(ingr,ingredientCount);
		ingredientCount++;
		cost.add(ingr.getCost());
		calorieCount += ingr.getCalorieCount();
		
		
	}
	
	/*
	 * The eatSOmePizza method takes in a fraction 
	 * and returns a new fraction of the difference between the
	 * two pizzas. It gets a common denominator and
	 * sutracts the numerator
	 */
	public void eatSomePizza(Fraction	amt)
	{
		double fracDec1 = (double)(myPizza.getNumerator()/(double)myPizza.getDenominator());
		double fracDec2 = (double)amt.getNumerator() / (double)amt.getDenominator();
		if(fracDec1 - fracDec2  == 0)
			throw new RuntimeException("No pizza left");
		if(fracDec2 > fracDec1)
			throw new PizzaException("Not enough pizza");
			
		myPizza = myPizza.remove(amt);
	}
	
	/*
	 * The getMadeDate method returns 
	 * a new date object for when the pizza
	 * was made
	 */
	public Date getMadeDate() 
	   { 
		return new Date(dateMade); 
		}

	/*
	 * The compareToBySize method compares the
	 * object taken in to this classes pizza and 
	 * checks to see if they have the same size
	 */
	@Override
	public int compareToBySize(Object obj) {
		if(obj == null)
			throw new PizzaException("Object is null");
	
		if(!(obj instanceof Pizza))
			throw new PizzaException("Not a pizza");
	
		Pizza that = (Pizza) obj;	

		if(getRemainingArea() > that.getRemainingArea())
			return 1;
		else if(getRemainingArea() == that.getRemainingArea())
			return 0;
		else 
			return -1;
		

	}

	/*
	 * The compareTo override compares the object 
	 * takes in by looking at its price. If this classes
	 * price is larger than return a 1
	 * else return -1 and if equal return 0;
	 */
	@Override
	public int compareTo(Object o) {
		if(o == null)
			throw new PizzaException("Object is null");
	
		if(!(o instanceof Pizza))
			throw new PizzaException("Not a pizza");
	
		Pizza that = (Pizza) o;	

		if(this.cost.getMoney() > that.getCost())
			return 1;
		else if(this.cost.getMoney() == that.getCost())
			return 0;
		else 
			return -1;
	}

	/*
	 * The compareToByCalories is very similar
	 * to the other compareTo methods but compares
	 * the pizzas based on the calories of all
	 * ingredients. 
	 */
	@Override
	public int compareToByCalories(Object o) {
		if(o == null)
			throw new PizzaException("Object is null");
	
		if(!(o instanceof Pizza))
			throw new PizzaException("Not a pizza");
	
		Pizza that = (Pizza) o;	

		if(getCalories() > that.getCalories())
			return 1;
		else if(getCalories() == that.getCalories())
			return 0;
		else 
			return -1;
	}
	
	/*
	 * setShape method is a setter
	 * for shape to determine if pizzaShape
	 * is going to be square or circle
	 */
	public	void	setShape(Shape	s)	
	{	
		pizzaShape	=	(Shape)s.clone();
	}
	
	/*
	 * getShape is a getter method for
	 * our variable pizzahape and returns
	 * a new shape
	 */
    public	Shape	getShape()	
    {	
    	return	(Shape)	pizzaShape.clone();
    }
    
    /*
     * 
     * The toString method returns a String representation
     * of the cost, calories, remaining fraction,area, shape and
     * timeStamp for the class.. 
     */
    public String toString()
    {
    	String retVal = "";
    	
    	retVal += ("Pizza has a price: " + cost.getMoney() + "and  calories: " + 
    	this.calorieCount +  " , Fraction remiaining: " + getRemainingFraction() 
    	+ " and area left: " + getRemainingArea() +" and shape: " + tempShape
    	+ "Date Made: " + getMadeDate());
    	
    	return retVal;
    }

	


}