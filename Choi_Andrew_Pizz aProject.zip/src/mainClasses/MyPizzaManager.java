package mainClasses;

/*
 * Andrew Choi
 * 
 * CSS 143 MyPizzaManager class
 * 
 * June 10 2019
 * 
 * This class ties this whole project together by 
 * combining all the previous classes. This class
 * contains a array of pizzas and several sort methods 
 * to organize the data. It also has a displayAllPizza 
 * method that prints out all the pizzas.These methods
 *  are basically all called in the driver. I couldnt quite get 
 *  my quicksorts to be working, they throw a class
 *  cast excetion. 
 */
import java.util.Scanner;

import java.util.*;

public class MyPizzaManager extends PizzaManager
{
	//Arraylist to hold pizzas
  private ArrayList<Pizza> pizzas = new ArrayList<Pizza>();
  private int pizzaCounter = 0;
  
  /*
   * The displayAllPizzas method prints
   * out all the pizzas in the arraylist. 
   * It is a void method and is used in 
   * the driver. 
   */
   protected void displayAllPizzas()	
   {
	   for(int i = 0; i < pizzas.size(); i++)
	  System.out.println(pizzas.get(i) + " \n ");
   }
   
   /*
    * The getNextChar method gets
    * the first char of the users input 
    * from scanner and returns it
    */
   protected	char	getNextChar()
   {
	   Scanner user = new Scanner(System.in);
	   String userInput = user.next();
	   char firstLet = userInput.charAt(0);
	   return firstLet;
   }
   /*
    * The getNextInt is similar to the get
    * nextChar method where it ask the user for 
    * a input but innstead returns the entire 
    * number. 
    * 
    */
   protected	int	 getNextInt()
   {
	   Scanner user = new Scanner(System.in);
	   int userInput = user.nextInt();
	   return userInput;
   }
   
   /*
    * The eatSomePizza method  takes in a 
    * user input from scanner and saves it into
    * an array after splitting at the division symbol.
    * It then subtracts a pizza in our arraylist 
    * based on the user input.
    * 
    */
   protected	void	eatSomePizza()
   {
	   Scanner user = new Scanner(System.in);
	   System.out.println("What is the fractional amount	you want to	eat?");
	   String fracAmount = user.next();
	   System.out.println("What is the index you want to eat at?");
	   int index = user.nextInt();
	 
	   System.out.println(fracAmount);
       String[] split = fracAmount.split("/");
       
       //Here I am splitting the fraction where the 
       //division sign occours.
       int num = Integer.parseInt(split[0]);
       //Storing the numerator in num.
       int denom = Integer.parseInt(split[1]);
       
       Pizza piz = (Pizza)pizzas.get(index);
      
       try
       {
    	   double temp1 = piz.getRemainingFraction().getNumerator()/
    			   piz.getRemainingFraction().getDenominator();
    	   
    	   double temp2 = (double)num/(double)denom;
    	   
    	   if (temp2 < 0)
    	   {
    		   System.out.println("Negative input");
    		   throw new PizzaException("Negative input");
    	   }
    	      
    	   piz.eatSomePizza(new Fraction(num,denom));
    	   System.out.println("Eating: " + num+ "/" + denom + " of the pizza");
    	   
    	   if(temp1 == 0)
     	  {
     		  pizzas.remove(index);
     		  pizzaCounter--;
     		  System.out.println("No pizza left to eat");
     	  }
    	   
    	   else if(temp1-temp2 < 0)
    	   {
    		   System.out.println("Negative pizza");
    		   throw new PizzaException("Negative pizza");
    	   }
       }
       catch(PizzaException e)
       {
       throw new PizzaException("Pizza could not be eated");
       }
   }

       
   /*
    * 
    * The quickSort by calories method returns the 
    * arrayList of Pizzas in a sorted orer by using
    * recursion and calling the helper methods 
    */
     protected void quickSortByCalories()	
     {
    	 sortCalorie(0,pizzas.size()-1);
     }
     
     /*
      * The partitionCalorie method is a helper method 
      * for the recursivequickSort by using
      * several while loops to find the partition value.
      */
     public int partitionCalorie(int start, int end)
       {	
    	 //Choosing middle value as pivot
   		int pivotValue = (pizzas.get((start + end)/2).getCalories()) ;
   
   		while(( end-start+1) > 1)//Base case is size 1 or 0
   		{
   			//While loop for if the index at low is less than pivot
   			
   			while(( (pizzas.get(start).getCalories()) < pivotValue))
   			{
   				start++;
   			}		
   			//While loop for if the index at high is less than pivot
   			while(pizzas.get(end).getCalories() > pivotValue) {
   				end--;
   			}

   			if(start <= end)
   			{
   				pizzas.swap(start++,end--);
   			}
   			
   		}	
   		return start;
   
   	}
   	
   	/*
   	 * The sort method is where the recursion occours
   	 * in this class. The method takes in a array and two ints.
   	 * It calls the partition method and compares that with 
   	 * the two ints. 
   	 * 
   	 */
     public void sortCalorie( int start, int end)
 	{
 		int splitIndex = partitionCalorie(start , end);
 		//After we get pivot index we look for more work to do
 		if(start < splitIndex) 
 			//Recursive step
 			sortCalorie(start,splitIndex-1);

 		if(end > splitIndex) 
 			//Recursive step
 			sortCalorie(splitIndex, end);

 	}
   	
     
     //--------------------------------------------------------------------
     /*
      * This i a facade for the recursive searching
      * by calling the helping methods partition and 
      * sortSize
      */
     protected void quickSortBySize()
     {
    	 sortCalorie(0,pizzas.size()-1);
     }
     /*
      * The partitionSize method is a helper method 
      * for the recursivequickSort for size by using
      * several while loops to find the partition value.
      */
     public int partitionSize(int start, int end)
       {	
    	   int low = 0;
    	   int high = pizzas.size()-1;
    	 //Choosing middle value as pivot
   		double pivotValue = (pizzas.get(low).getRemainingArea() + pizzas.get(high).getRemainingArea())/ 2;
   		System.out.println(pivotValue);
   	
   		while(( high-low +1) > 1)//Base case is size 1 or 0
   		{
   			//While loop for if the index at low is less than pivot
   			while(pizzas.get(low).getRemainingArea() < pivotValue)
   			{
   				low++;
   			}		
   			//While loop for if the index at high is less than pivot
   			while(pizzas.get(high).getRemainingArea() > pivotValue) {
   				high--;
   			}

   			if(low <= high)
   			{
   				pizzas.swap(low,high);
   				low++;
   			   high--;
   			}
   		}	
   		return low;
   
   	}
   	
   	/*
   	 * The sort method is where the recursion occours
   	 * in this class. The method takes in a array and two ints.
   	 * It calls the partition method and compares that with 
   	 * the two ints. 
   	 */
     public void sortSize( int start, int end)
 	{
 		int splitIndex = partitionCalorie(start , end);
 		//After we get pivot index we look for more work to do
 		if(start < splitIndex) 
 			//Recursive step
 			sortSize(start,splitIndex-1);

 		if(end > splitIndex) 
 			//Recursive step
 			sortSize(splitIndex, end);

 	}
     //------------------------------
     /*
      * The quickSortByPrice method
      * looks at the pizzas in the arraylist
      * and sorts them based off of the price
      * Facade method. 
      */
     protected void quickSortByPrice()
     {
    	 sortPrice(0,pizzas.size()-1);
     }
     
     /*
      * The partitionPrice is a helper method
      * to find the pivotValue and price of it.
      * Uses serveral while loops to itterate through
      * the list
      */
     public int partitionPrice(int start, int end)
     {	
  	 //Choosing middle value as pivot
 		double pivotValue = (pizzas.get((start + end)/2).getCost()) ;
 	
 	
 		while(( end-start+1) > 1)//Base case is size 1 or 0
 		{
 			//While loop for if the index at low is less than pivot
 			
 			while(( pizzas.get(start)).getCost() < pivotValue)
 			{
 				start++;
 			}		
 			//While loop for if the index at high is less than pivot
 			while(pizzas.get(end).getCost() > pivotValue) {
 				end--;
 			}

 			if(start <= end)
 			{
 				pizzas.swap(start++,end--);
 			}
 			
 		}	
 		return start;
 
 	}
     
     /*
      * Sort price is another helper method
      * and actually does the sorting for the 
      * arraylist by looking at the start and 
      * end values. 
      */
     public void sortPrice( int start, int end)
  	{
  		int splitIndex = partitionPrice(start , end);
  		//After we get pivot index we look for more work to do
  		if(start < splitIndex) 
  			//Recursive step
  			sortSize(start,splitIndex-1);

  		if(end > splitIndex) 
  			//Recursive step
  			sortSize(splitIndex, end);

  	}
     /*
      * The add random pizza creates a new
      * Pizza with no arguments and adds it
      * to the arraylist in this class
      */
 	public void addRandomPizza()
 	{
 		pizzas.add(new Pizza(),pizzaCounter);
 	}
       
 	/*
 	 * The removeDayOld method checks to see
 	 * if the pizzas are over a day old and if they 
 	 * are it remvoes it from the list
 	 * 
 	 */
 	protected	void	removeDayOldPizzas()
 	{
 	
 		if(pizzas.size() > 0)
     	{
 		      for(int i = 0; i < pizzas.size(); i++)
 		      {
 		    	  if(super.getCurrentDate().getDay() - pizzas.get(i).getMadeDate().getDay()>=1)
 		    	  {
 		    		  pizzas.remove(i);
 		    		  pizzaCounter--;
 		    		  System.out.println("Pizza removed for being too old");
 		    	  }
 		      }
 	     }
 	}
   
 	/*
 	 * The binarySeachByCalories takes in a int and 
 	 * searches through the arraylist based on 
 	 * the calorie amount. List should be sorted prior
 	 * to this method call
 	 */
 	protected	int	binarySearchByCalories(int	targetCal)	
 	{
 		
 	        int start = 0;
 	        int end = pizzas.size()-1;
 	        int mid = ((start + (end))/2);
 	       
 	        
 	        while(start <= end)
 	        {
 	        	mid =(start + end)/2;
 	        	if(pizzas.get(mid).getCalories() == targetCal)
 	        	{
 	        		System.out.println(mid);
 	        		return mid;
 	        	}
 	        	else if(pizzas.get(mid).getCalories() > targetCal)
 	        		end = mid-1;
 	        	else
 	        		start = mid+1;
 	        }
 	       System.out.println("pizza not found");
 	        return -1;
 	}
 	
 	/*
 	 The linearSearchByDay method searches
 	 the arraylist itteratively by using a for loop 
 	 and checking to see which days the pizzas
 	 were made.
 	 */
 	protected	int linearSearchByDay(int day)
 	{
 		System.out.println(pizzas.objectAt(0));
 		int day5 = ((Pizza)pizzas.objectAt(0)).getMadeDate().getDay();
 				String retVa = "";
 				int count = 0;
 		for(int i = 0; i < pizzas.size(); i++)
 		{
 		     if(day== ((Pizza) pizzas.objectAt(i)).getMadeDate().getDay())
 		     {
 		    	 System.out.println(pizzas.objectAt(i) + " Was made on the current day");
 		    	 count++;
 		     }
 	}
 		  if(count == 0)
 			  System.out.println("No pizza made that day");
 		  
 		return count;
}
 	
 	/*
 	 * The reversePizzasWithStack method
 	 * uses the instance variable stack and 
 	 * reverses it by using a java built stack.
 	 * I empty the arrayList and re enter the 
 	 * pizzas
 	 */
 	protected void reversePizzasWithStack()
 	{
 		int count = 0;
 		Stack<Pizza> pizzaStack = new  Stack<Pizza>();
 		for(int i = 0; i< pizzas.size(); i++)
 		{
 			pizzaStack.push(pizzas.get(i));
 			count++;
 		}
 		while(pizzas.size() != 0)
 		{
 			pizzas.remove(0);
 		}
 		System.out.println(pizzas.size());
 		while(count > 0)
 		{
 		pizzas.add(pizzaStack.pop(),pizzas.size());
 		count--;
 		}
 		
 	}
}
