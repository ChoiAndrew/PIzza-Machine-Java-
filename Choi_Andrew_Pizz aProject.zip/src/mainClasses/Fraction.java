package mainClasses;

import java.util.Scanner;

/*
 * Andrew Choi
 * 
 * CSS 143 Fraction class implements comparable
 * 
 * June 10 2019
 * 
 * This class resembles a fraction class  and contians
 * a numerator and denominator. This homework was
 * used earlier on in the quarter but now i have 
 * implemeted the comparable interface and made a 
 * remove method for when pizza is eaten. The fraction
 * resembles how much of the pizza is left. 
 */
public class Fraction implements Comparable{
 
	
	private final int numerator;
    private  final int denominator;
    private static Scanner arr;
    private static Scanner count;
    
    /*
     * The compareTo method is a override for the
     * comparable interface and compares the value of 
     * the two fractions.  I store the fractions in 
     * its decimal form and compare the decimal 
     * values.
     */
	@Override
	public int compareTo(Object obj) 
	{
		if(obj == null)
			throw new RuntimeException("Null object");
		if(!(obj instanceof Fraction))
			throw new RuntimeException("Not a Fraction");
		Fraction that = (Fraction)obj;
		double thisFraction = this.numerator/this.denominator;
		double thatFraction = that.getNumerator()/that.getNumerator();
		if(thisFraction > thatFraction )
			return 1;
		else if(thisFraction == thatFraction )
			return 0;
		else
			return -1;
	}

     
    /*
     * Empty constructor means 
     * that there is a full pizza so  I 
     * initialized both the numerator and
     * denominator to equal 0
     */
    public Fraction()
    {
    	numerator = 1;
        denominator = 1;
    }
    
    /*
     * Overloading constructor that takes in two integers 
     * and sets it to the numerator and denominator.
     */
    public Fraction( int num, int denom) 
    {
     if (denom <= 0)
    	 throw new IllegalArgumentException("Denominator is less than or equal to 0");
    		 
    	 int copyNum = num;
         int copyDenom = denom;
         int GCD = 0;
         
         while(copyNum != 0 && copyDenom!= 0 )
         {
         	//Using a while loop and Eucids method to find GCD
             int temp = copyDenom;
             copyDenom = copyNum % copyDenom;
             copyNum = temp;
             GCD = copyDenom + copyNum;
         }
         this.numerator = num/GCD;
         this.denominator = denom/GCD;
        
    }
    
    /*
     * Constructor that takes in a fraction and
     * makes a copy of it to prevent privacy leaks
     * and combined leashes. 
     */
    public Fraction(Fraction that)
    {
    	this.numerator = that.numerator;
    	this.denominator = that.denominator;
    }
    
    /*
     * boolean method to check if the two fractions
     * are equal to each other.  First I check if object
     * is null then I check the fraction. 
     */
    public boolean equals(Object other)
    {
    	boolean sameFraction = false;
    	
    	if(other != null)
    	{
    	Fraction newFraction = (Fraction)other;
    	if(this.numerator==newFraction.getNumerator()
    			&& this.denominator == newFraction.getDenominator())
    	{
    	    sameFraction = true;
    	}
    	else
    	{
    	   sameFraction = false;
    	}
    }
    	return sameFraction;
    }
    
/*
 * A getter method that return the 
 * numerator
 */
	public int getNumerator() {
		return numerator;
	}
        

   /*
    * A getter method for the denominator
    * that returns the value of the classes
    * denominator
    */
	public int getDenominator() 
	{
		return denominator;
	}


	/*
	 * A toString method for the Fraction Class
	 * that returns a string of the numerator and
	 * denominator.
	 */
	public String toString()
	{
	    String retVal = "";
	    retVal = this.numerator + "/" + this.denominator;
	    return retVal;
	}
	
	/*
	 * The remove method is used to subtract from
	 * this classes fraction. Since the numerator 
	 * and denominator are immutable I have to 
	 * create a new Fraction each time
	 */
	public Fraction remove(Fraction frac)
	{
		if(frac == null)
			throw new RuntimeException("Null Fraction");
		//If the denominators are the same then subtract only 
		//the numerator
		if(this.denominator == frac.getDenominator())
		{
			int tempNum = this.numerator - frac.getNumerator();
		     return new Fraction(tempNum,getDenominator());
		}
		else
		{
			//Get a common denominator for both fractions and
			//then subtract the numerator
			int thisNum = this.numerator * frac.getDenominator();
			int thisDenom = this.denominator * frac.getDenominator();
			int thatNum = frac.getNumerator() * this.denominator;
			int thatDenom = frac.getDenominator() * this.denominator;
			
			int tempNum = thisNum-thatNum;
		     return new Fraction(tempNum,thisDenom);
		}
		
		
	}
	
	
}


