package mainClasses;

/**
 * Andrew Choi
 * 
 * CSS 143 Stack class used in MyPizzaManager
 * 
June 10
 *  
 * This class represents a built in java stack. It contains 
 * a array named numElements and a counter to keep track 
 * of the number of elements. A stack is ordered in a Lifo 
 * (Last in first out). This class will hold
 * a list of pizzas to help reverse the order. This class has the 
 * push and pop method to add objects in the array and removing 
 * the last thing added. It also contains other methods such as
 *  isEmpty, size, toString and Equals.
 */
public class Stack
{

private int numElements = 0;
private Object[] data = new Object[100];

	
	/*
	 * The push method adds a value 
	 * to the array and increments the 
	 * count
	 * 
	 */
	public void push(Object x)
	{
		while(numElements >= data.length)
		{
			resize();
		}
		data[numElements] = x;
		numElements++;
	}
	
	/*
	 * The resize method is called
	 * when pushing objects and 
	 * doubles the size of the array length
	 */
	private void resize() {
		//Add double the amount of spaces
		Object[] data2 = new Object[data.length * 2];
		for (int i = 0; i <data.length; i++) {
			data2[i] = data[i];
		}
		data = data2;
	}
	
	/*
	 * The pop method removes the last 
	 * object that was added into the array
	 */
	public Object pop()
	{
		
		return data[--numElements];
	}
	
	/*
	 * This method checks to see
	 * if the array is empty. 
	 */
	public boolean isEmpty()
	{
		return numElements == 0;
	}
	
	
	/*
	 * Returns the number of elemtnes in
	 * the array.
	 */
	public int size()
	{
		return numElements;
	}
	
	/*
	 * The toString method is used to 
	 * hold all the values in a sting and
	 * retunrs that string. 
	 */
	public String toString()
	{
		String retVal = "";
		for(int i = 0; i < numElements; i++)
		{
			retVal += data[i] + " " + "\n";
		}
		return retVal;
	}
	
	/*
	 *This is the overridden method for the equals
	 *method. It compares the two array list 
	 */
	public boolean equals(Object other)
	{
		boolean sameStack= false; 
		
		if(other == null)
			return false;
		if (!(other instanceof Stack))
			return false;
		Stack castedObject  = (Stack) other;
		if(castedObject.size() != size())
			return false;
		for(int i = 0; i< numElements; i++)
		{
			if(data[i] == castedObject.data[i])
				sameStack = true;
			else
			return false;
		}
		return sameStack;
	}


   }
	
