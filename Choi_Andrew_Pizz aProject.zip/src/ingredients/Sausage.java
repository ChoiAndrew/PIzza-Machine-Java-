package ingredients;
import mainClasses.Money;

/*
 * Andrew Choi
 * 
 * CSS 143 Sausange subclass
 * 
 * June 10 2019
 * 
 * The sausage subclass, similarly to
 * the pepperoni subclass both extends 
 * from the meat class. This class contains
 * one method that sets the description, cost
 * and caloric amount.
 */
public class Sausage extends Meat{
/*
 * Sausage constructor that sets the 
 * description, amount and caloric amount 
 * into the parent class by calling the super 
 * function.
 */
	public Sausage() 
	{
		super("Sausage", new Money(2,75), 325);
	}

}
