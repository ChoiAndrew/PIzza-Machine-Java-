package ingredients;
import mainClasses.Money;
import java.awt.Color;
/*
 * Andrew Choi
 * 
 * CSS 143 Cheese clase extends ingredient
 * 
 * June 10 2019
 * 
 * This class represents the cheese for the
 * pizza. Like the Base classIt contains three 
 * methods the constructor, toStrihg and equals method.
 * This class is subclassed from the parent class
 * Ingredient and calls the super function in the
 * constructor to set the description, amount 
 * and calorie amount.
 */

public class Cheese extends Ingredient
{
	/*
	 * Constuctor for the Cheese class that
	 * sets the description, amount and 
	 * caloric amount in the parents 
	 * class. 
	 */
    public Cheese(String desc, Money mon, int cal) {
		super(desc, mon, cal);
	}

    /*
     *Th toString method returns a string representation
     *of the description, cost and caloric amount by calling
     *the ingredient parent class by using the super 
     *function
     */
    public String toString()
    {
    	return ("Description: " + super.getDescription() + 
    			" Cost: " + super. getCost() + " Calories: " + 
    			super.getCalorieCount());
    }
    
    /*
     * The equals method takes in a object 
     * and checks to see if this classes 
     * instance variables equal the objects instance
     * variables. 
     * 
     */
    public boolean equals(Object obj)
    {
    	if(obj == null)
			throw new RuntimeException("Object null");
    	//Null check
		if(!(obj instanceof Ingredient))
			throw new RuntimeException("Object not Cheese");
		//Instance of check
		Cheese that = (Cheese) obj;
		if(super.equals(obj) == true)
             return true;
		else
		return false;
    }
 
}
