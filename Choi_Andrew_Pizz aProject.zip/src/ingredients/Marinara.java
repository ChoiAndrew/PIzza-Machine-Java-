package ingredients;
import mainClasses.Money;
/*
 * Andrew Choi
 * 
 * CSS 143 Marinara Sauce subclass
 * 
 * June 9 2019
 * 
 * This class is subclassed from Base and 
 * represents Marinara sauce. It is at the 
 * bottom of the ingredient heiarchy and like
 * the rest of the leaves it contains only the 
 * constructor that to set its description, cost and 
 * calorie count in the Base class
 */
public class Marinara extends Base{

	/*
	 * The no arg constructor for the class 
	 * set the description, price and calorie
	 * count by calling the base constructor.
	 */
	public Marinara() 
	{
		super("Marinara Sauce", new Money(1,75), 275);
	}

}
