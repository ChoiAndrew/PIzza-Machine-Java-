package ingredients;
import mainClasses.Money;

/*
 * Andrew Choi
 * 
 * CSS 143 Goat cheese subclass
 * 
 * Jun 10 2019
 * 
 * 
 * This class represents a cheese object that 
 * will later be used as a toping for the pizza class.
 * Similarly to the Alfredo class this class is at the 
 * bottom of the Ingredient hierchy and contains only
 * the constructor. The consturctor calls the parent class
 * using super and provides a description, price and
 * caloric intake. 
 */
public class Goat extends Cheese{

	/*
	 *The no arg constructor for Goat cheese 
	 *provides the parent class a description,
	 *price and calories for the pizza. I create
	 *a new Money object here to prevent 
	 *privacy leak. 
	 */
	public Goat() 
	{
		super("Goat Cheese", new Money(0,75), 263);
	}

}
