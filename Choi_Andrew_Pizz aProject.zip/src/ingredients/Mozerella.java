package ingredients;
import mainClasses.Money;

/*
 * Andrew Choi
 * 
 * CSS 143 Mozerella Cheese subclass
 * 
 * June 10 2019
 * 
 * This class represents Mozerella cheese
 * iat the bottom of the ingredient hierarchy tree.
 * This class only contains a no arg constructor 
 * that sets the description, amount and 
 * caloric intake by calling super. The class
 * will later be used as a topping for the pizza 
 * class. 
 *                    
 * 
 */
public class Mozerella extends Cheese
{
	/*
	 * Empty no arg constructor for this subclass.
	 * It sets the description, amount  and calories
	 * for mozerella cheese later to be used as a 
	 * Toping. 
	 */
     public Mozerella()
     {
    	 super("Goat cheese", new Money(0,75), 320);
     }
}
