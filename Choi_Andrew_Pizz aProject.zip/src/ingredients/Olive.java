package ingredients;
import mainClasses.Money;

import java.awt.Color;

/*
 * The Olive class is one of the leaves
 * of the ingredient hiearchy. It contains a 
 * description, amount, number of calories and
 * a color later to be used as a topping for the 
 * pizza class. 
 */
public class Olive extends Vegetable {

	/*
	 * The Olive constructor sets the description, 
	 * amount, calories and color by calling the 
	 * super function.
	 */
	public Olive()
	{
		super("Black olive", new Money(0,25), 15, Color.BLACK);
	}

}
