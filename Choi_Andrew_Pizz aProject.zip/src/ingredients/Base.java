
package ingredients;
import mainClasses.Money;
/*
 * Andrew Choi
 * 
 * CSS 143 Base clase extends ingredient
 * 
 * June 10 2019
 * 
 * This class represents the base for the
 * pizza. It contains three methods the 
 * constructor, toStrihg and equals method.
 * This class is subclassed from the parent class
 * Ingredient and calls the super function in the
 * constructor to set the description, amount 
 * and calorie amount.
 */

public class Base extends Ingredient
{
	/*
	 * Constuctor for the Base class that
	 * sets the description, amount and 
	 * caloric amount in the parents 
	 * class. 
	 */
    public Base(String desc, Money mon, int cal) {
		super(desc, mon, cal);
	}    
		
    /*
     * The toString method returns a String 
     * of the description, cost and amount of 
     * calories by calling super. 
     */
    public String toString()
    {
    	return ("Description: " + super.getDescription() + 
    			" Cost: " + super. getCost() + " Calories: " + 
    			super.getCalorieCount());
    }
    
    /*
     *  The equals method takes in a object and 
     *  checks to see if this base is the same
     *  as the object taken in. Checks to see if it 
     *  is a null and if it is a instance of base. 
     */
    public boolean equals(Object obj)
    {
    	if(obj == null)
			throw new RuntimeException("Object null");
		if(!(obj instanceof Base))
			throw new RuntimeException("Object not Base");
		Base that = (Base) obj;
		if(super.equals(obj) == true )
             return true;
		else
		return false;
    }
 
}

