package ingredients;
import mainClasses.Money;

/*
 * This is a abstract class and contains 
 * most of the classes for this homework 
 * assignment. It is made absract so all the 
 * subclasses can inherit these methods. This 
 * class contains a description, a cost and a 
 * calorie count, later to be used to represent 
 * a pizza. 
 */
public abstract class Ingredient implements Comparable {
	
	private String description;
	private Money cost;
	private int calorieCount;
	
	/*
	 * empty no arg constructor for later
	 * use if needed. 
	 */
	public Ingredient()
	{
	}
	/*
	 * The main constructor for this class that 
	 * takes in a string that represents a description
	 * a Money object that represents the cost and 
	 * a int that represents a calorie count. Called setters
	 * to set these values. 
	 */
	public Ingredient(String desc, Money mon, int cal) {
		setDescription(desc);
		setCost(mon);
		setCalorieCount(cal);
		//throw new RuntimeException("Ingredients not done");
	}
	
	/*
	 * COpy constructor for this class used in 
	 * both cloneable and used to prevent privacy
	 * leaks. Called when a new instance is wanted. 
	 * 
	 */
	public void Ingrediant(Ingredient other)
	{
		setDescription(other.getDescription());
		setCost(other.getCost());
		setCalorieCount(other.getCalorieCount());
	}
	
	/*
	 * The compareTo method is overriden from 
	 * the comparable interface and compares 
	 * the object takes in to the current ingredients.
	 * Returns either -1,0 or 1 based on the ingredients 
	 * price.
	 */
	@Override
	public int compareTo(Object obj) 
	{
		//Null check
		if(obj == null)
			throw new RuntimeException("Object null");
		
		//Instance of check
		if(!(obj instanceof Ingredient))
			throw new RuntimeException("Object not ingredientl");
		
		Ingredient that = (Ingredient) obj;
		//Casting object to Ingredient
		if (this.cost.getMoney() - that.cost.getMoney() == 0)
		   return 0;	
		   else if (this.cost.getMoney() - that.cost.getMoney() > 0)
		    return 1;
		 else 
			 return -1;
	}

	/*
	 * The equals method taes in a object and 
	 * checks to see if the object taken in is the
	 * same as this classes variables by checking
	 * the Calories, amount and description
	 */
	public boolean equals(Object obj)
	{//Null check
		if(obj == null)
			throw new RuntimeException("Object null");
		//Instance of check 
		if(!(obj instanceof Ingredient))
			throw new RuntimeException("Object not ingredientl");
		//Casting object
		Ingredient that = (Ingredient) obj;
		if(this.cost.getMoney() == that.cost.getMoney() &&
				this.calorieCount == that.calorieCount &&
				this.description.equals(that.description))
			return true;
		else 
			return false;
	}

	/*
	 * a getter for the description that 
	 * returns a string of the value contained
	 * withing "description".
	 */
	public String getDescription() {
		return description;
	}

/*
 * A setter for description that takes in 
 * a String and assigns the instance variable
 * description to that string
 */
	public void setDescription(String description) {
		this.description = description;
	}

/*
 * The getCost method returns a new 
 * Money object of the cost to prevent
 * privacy leaks
 */
	public Money getCost() 
	{
		return new Money(cost);
	}

/*
 * The setCost method takes in a Money
 * object and sets the cost instance 
 * variable to that money amount
 */
	public void setCost(Money mon) {
		this.cost = new Money(mon);
	}

/*
 * The hetCalorieCount method
 * returns a int of the calorie count
 * stored in this class
 */
	public int getCalorieCount() {
		return calorieCount;
	}

/*
 * The setCalorieCount method takes in a 
 * int and sets the calorieCOunt equal to 
 * the integer.
 */
	public void setCalorieCount(int calorieCount) {
		this.calorieCount = calorieCount;
	}
	
	/*
	 * The toString method holds the description,
	 * cost an calorie amount into a variable 
	 * called retVal and returns it at the end. 
	 * 
	 */
public String toString()
 {
	  String retVal = "";
	  
	  retVal += "Descripton: " + getDescription() + "Cost: " + getCost().toString() + 
			  " Calories: " +  getCalorieCount();
	  
	  return retVal;
 }
}
