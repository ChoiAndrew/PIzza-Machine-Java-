package ingredients;
import java.awt.Color;

import ingredients.Ingredient;
import mainClasses.Money;

/*
 * This class represents the meat toppings 
 * for the pizza. There are two subclasses 
 * for this class, the pepperoni and sausage. This
 * class contains three methods the constructor,
 * toStrinf and equals method. It sets the description
 * , amount and calories in the sonstructor. 
 * 
 */
public class Meat extends Ingredient
{
	
	/*
	 * The constructor for this class that sets the
	 * description, amount and calorie amount to 
	 * the parent class by calling the super 
	 * function
	 */
    public Meat(String desc, Money mon, int cal) {
		super(desc, mon, cal);
	}

    /*
     * a toString method that returns a string of 
     * the desction, cost and calorie amount 
     * by calling the super method from the 
     * parent class. 
     * 
     */
    public String toString()
    {
    	return ("Description: " + super.getDescription() + 
    			" Cost: " + super. getCost() + " Calories: " + 
    			super.getCalorieCount());
    }
    
    /*
     * The equals method checks to see if the object
     * taken in is equal to this classes instance 
     * variables by clalling the super function
     * 
     */
    public boolean equals(Object obj)
    {
    	if(obj == null)
			throw new RuntimeException("Object null");
		if(!(obj instanceof Meat))
			throw new RuntimeException("Object not Meat");
		Meat that = (Meat) obj;
		if(super.equals(obj) == true )
             return true;
		else
		return false;
    }
    
}
