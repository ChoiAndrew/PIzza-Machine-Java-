package ingredients;
import mainClasses.Money;

/*
 * Andrew Choi
 * 
 * CSS 143 Alfredo subclass
 * 
 * Jun 10 2019
 * 
 * This class represents one of the leaves in the 
 * Ingredient hiearchy tree. It only has one method,
 * the constructor and calls to parent class to provide
 * a ingredient description, a price and a calorie count.
 * The purpose of this class is to practice inheritance
 * and provide the pizza class with the necessary 
 * ingredients. 
 * 
 * 
 */
public class Alfredo extends Base{

//I am really confused as to what the instructions wants. 
	//On page 4 it says to provide descrption, cost and calories
	// in constructor but on page 11 its says to just provide 
	//description and calories without the cost.
	
	/*
	 * This constructor provides the parent class
	 * with a description, price and a calorie count,
	 * later to be used in the pizza classes.
	 * I went with the instructions on page 4. 
	 */
	public Alfredo() 
	{
		super("Alfredo sauce", new Money (2,50),650);
	}
}
