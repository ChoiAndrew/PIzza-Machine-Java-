package ingredients;
import mainClasses.Money;

import java.awt.Color;
/*
 * Andrew Choi
 * 
 * CSS 143 Pepper subclass
 * 
 * June 10 2019
 * 
 * This class resembles a green bell pepper 
 * subclassed from vegetable. It contains 
 * one constructor that sets the description, 
 * amount, caloric intake and the color. Purpose
 * of this class was to practice inheritance and
 * to be used in our pizza class. 
 */
public class Pepper extends Vegetable{

	/*
	 * The no arg pepper constructor sets
	 * the description, amount, color and 
	 * amount of calories by using by calling
	 * super. 
	 */
	public Pepper()
	{
		super("Green Bell Pepper", new Money(0,65), 20,Color.GREEN);
	}
	
}
