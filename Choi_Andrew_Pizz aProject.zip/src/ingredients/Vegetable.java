package ingredients;
import java.awt.Color;

import mainClasses.Money;

/*
 * Andrew Choi
 * 
 * CSS 143 Vegetable class extends ingredient
 * 
 * June 10 2019
 * 
 * This class represents a vegetable topping for
 * the pizza class and extends the parents class
 * ingredient. It has a few overload constructors 
 * to take in the price, description, calorie amount
 * and the color. Also has a toString and equals 
 * method. 
 */
public class Vegetable extends Ingredient
{
	private Color color;
	/*
	 * An empty no arg constructor 
	 * that is there in case I need it later 
	 * in this project
	 */
	public Vegetable()
	{
	}
	/*
	 * A overload constructor that takes in a String 
	 * description, a Money amount and  a int value of 
	 * the calorie amount. Calls super to set it in 
	 * ingredient class. 
	 */
    public Vegetable(String desc, Money mon, int cal) {
		super(desc, mon, cal);
	}
    
    /*
	 * A overload constructor that takes in a String 
	 * description, a Money amount , a int value of 
	 * the calorie amount and a color for the vegetable. 
	 * Calls super to set it in ingredient class. 
	 * 
	 * */
    public Vegetable(String desc, Money mon, int cal, Color col) 
    {
		super(desc, mon, cal);
		this.color = col;
    }
		/*
		 * This method is the toString for this class
		 * and returns a string representaion of the 
		 * description, cost, calorie amount and 
		 * color.
		 */
    public String toString()
    {
    	return ("Description: " + super.getDescription() + 
    			" Cost: " + super. getCost() + " Calories: " + 
    			super.getCalorieCount() + " Color: " + this.color);
    }
    
    /*
     * The equals method is a override method and 
     * checks to see if this object is equal to the instance 
     * of this class by calling the super function. 
     */
    public boolean equals(Object obj)
    {
    	//Null check
    	if(obj == null)
			throw new RuntimeException("Object null");
    	//Instance of check 
		if(!(obj instanceof Vegetable))
			throw new RuntimeException("Object not Vegetable");
		//Casting object to vegetable
		Vegetable that = (Vegetable) obj;
		//Super call
		if(super.equals(obj) == true && this.color.equals(that.color))
             return true;
		else
		return false;
    }
    /*
     * A getter for color that returns
     * the color variable stores in this
     * class
     */
	public Color getColor() {
		return color;
	}
	

	
}
