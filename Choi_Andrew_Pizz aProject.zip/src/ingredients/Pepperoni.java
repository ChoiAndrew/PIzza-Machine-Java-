package ingredients;
import mainClasses.Money;
/*
 * Andrew Choi
 * 
 * CSS 143 Pepperoni class 
 * 
 * June 10 2019
 * 
 * This class represents pepperoni  on a 
 * pizza by extending to the Meat class. Like 
 * the other toppings, it only contains a constructor
 * that sets the description, amount and number of
 * calories. The pepperoni class will later be used 
 * in the pizza class. 
 */
public class Pepperoni extends Meat {

	/*
	 * no arg constructor that sets the description,
	 * amount and calories for pepperoni. 
	 * Calles a new Money object to prevent 
	 * privacy leaks. Uses super to call parent
	 * constructor. 
	 */
	public Pepperoni()
	{
		super("Pepperoni", new Money(2,40), 550);
	}

}
