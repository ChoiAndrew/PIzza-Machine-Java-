package timeStamp;
import mainClasses.PizzaManager;
/*
 * Andrew Choi
 * 
 * CSS 143 timeStamp class
 * 
 * June 10 2019
 * 
 * This class is a IS a date and has a time.
 * This class was made to extend date 
 * and contains methods to get the date and 
 * time classses in the package and a toString
 * to report the hour, minute and seconds.
 */

/*
 * This class IS a Date and HAS a time
 * You can call the getters for either, but no setters
 * Also a good candidate for a class with final data items.
 */
public class TimeStamp extends Date {    
	private Time time;
	
/*
 * The constructor for TimeStamp takes in 
 * a date and time object and calls the super 
 * function to set the data to the parent class
 * and the time to the instance variable in 
 * this class
 */
	public TimeStamp(Date days, Time times) {
		super(days);
		time = times;
	}
	
	/*
	 * getter method for time that 
	 * returns a new time object  to 
	 * avoid privacy leaks
	 */
	public Time getTime() { 
		return new Time(time);
	}
	/*
	 * The getDate method is a getter for 
	 * date and returns a new instance of 
	 * date to avoid privacy leaks
	 */
	public Date getDate() {
		return new Date(this);
	}
	
	/*
	 * The toString method returns a String 
	 * value of the hours, minutes and 
	 * seconds. 
	 */
	public String toString() {
		return "TimeStamp at: " + time.getHour() + ":" + time.getMinute()+":"+ time.getSecond() + " and " + super.toString();
	}
}
