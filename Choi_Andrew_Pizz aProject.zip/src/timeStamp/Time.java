package timeStamp;

/*
 * Andrew Choi
 * 
 * CSS 143 Time class
 * 
 * June 10 2019
 * 
 * This class represents a time  and contians
 * a hour, minute and date. This class also
 *  implements the comparable interface and 
 *  overrides the compareTo method to check 
 *  if one time is greater than the other. This class
 *  will be used in the pizza manager class to 
 *  determine wait time for pizzas.
 */
public class Time implements Comparable {
	private int hour, minute, second = 0;

	/*
	 * Constructor for time class that sets 
	 * the hours, minutes and seconds. 
	 * Calls the setter method istead of 
	 * directly setting it to instance variables. 
	 */
	public Time(int hours, int minutes, int seconds) {
		setHour(hours);
		setMinute(minutes);
		setSecond(seconds);
	}

	/*
	 * Copy constructor for time that takes in
	 * a time object and copies the hours
	 * minutes and seconds over to this 
	 * classes instance variables.
	 */
	public Time(Time time) {
		this(time.hour, time.minute, time.second);
	}

	/*
	 * Getter method for hour that returns
	 * the amount of hours. 
	 */
	public int getHour() {
		return hour;
	}

	/*
	 * Setter method for hours that takes
	 * in a int and sets the instance variable
	 * to the int.
	 */
	public void setHour(int hour) {
		this.hour = hour;
	}

	/*
	 * This method returns the amount
	 * of minutes stores in the instance
	 * variable minute
	 */
	public int getMinute() {
		return minute;
	}

	/*
	 * This method is a setter for minute 
	 * that takes in a integer and sets the 
	 * minute variable to the integer.
	 */
	public void setMinute(int minute) {
		this.minute = minute;
	}

	/*
	 * The getter method for seconds
	 * returns the int value from the 
	 * variable seconds. 
	 */
	public int getSecond() {
		return second;
	}

	/*
	 * The setter for seconds takes in a 
	 * int value and sets the instance variable
	 * second to the int value.
	 */
	public void setSecond(int second) {
		this.second = second;
	}

	/*
	 * The toString is a override method
	 * for java where it returns a string of the
	 * hours, minutes and seconds.
	 */
	@Override
	public String toString() {
		return "Time [hour=" + hour + ", minute=" + minute + ", second="
				+ second + "]";
	}

	

	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (!(obj instanceof Time))
			return false;
		Time other = (Time) obj;
		if (hour != other.hour)
			return false;
		if (minute != other.minute)
			return false;
		if (second != other.second)
			return false;
		
		return true;
	}

	/*
	 * The compareTO method is a overidden 
	 * method from implementing comparable.
	 * I compare the hour at first, then minute and
	 * seconds. Return 1 if this date is greater than 
	 * "that date". 0 if the same and -1 if less than.
	 */
	@Override
	public int compareTo(Object that) {
		
		//If object is null
	      if (that == null)
	    	  throw new RuntimeException("object null");
	      if(!(that instanceof Time))
	    	  throw new RuntimeException("Not a time object");
	      //Casting object to time
	      Time casted = (Time) that;
	  if(this.hour > casted.getHour())
		    return 1;
	  else if(this.hour == casted.getHour() && this.minute > casted.getMinute())
		  return 1;
	  else if(this.hour == casted.getHour() && this.minute == casted.getMinute()
			  && this.second > casted.getSecond())
		  return 1;
	  else if(this.hour == casted.getHour() && this.minute == casted.getMinute()
			  && this.second == casted.getSecond())
		  return 0;
	  else 
		  return -1;
	}
	
	

}
