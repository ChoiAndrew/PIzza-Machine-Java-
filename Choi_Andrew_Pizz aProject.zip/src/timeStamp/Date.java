package timeStamp;

/** 
* Andrew Choi
* 
* CSS 143 Date Class
* 
* Jun 10 2019
*
* This class represents a date and contains
* a year, month and day. It also implements 
* the Comparable interface and overrides the 
* compareTo method to check which date is 
* greater. This will later be used in the pizza 
* classes.
*/

public class Date implements Comparable{

   private int year;
   private int month;
   private int day;
   
   /*
    * No arg constructor for the date class
    * that doesnt do anything. 
    */
   public Date()
   {
   }
   
   /*
    * This is my constructor for the date class that takes in 
    * three integers, a month, day and year. It then sets these
    * integers to the instance variables. 
    */
   public Date(int month, int day, int year)
   {
   	setYear(year);
   	setMonth(month);
   	setDay(day);
   }
   
   /*
    * This is my copy constructor for the date class
    * to prevent potential privacy leakes. 
    */
   public Date(Date other)
   {
   	setYear(other.getYear());
   	setMonth(other.getMonth());
   	setDay(other.getDay());
   }

   /*
    * This is my getter method for 
    * the yea which returns an integer.
    */
	public int getYear() 
	{
		return this.year;
	}

	/*
	 * This is my setter method for year. I check to see
	 * if the integer im taking in is between  2014 and
	 * 2024.
	 */
	public void setYear(int years) 
	{
		if(years <= 2024 && years >= 2014)
		{
			//checking if the year is between 2014 and 2024
		          this.year = years;
		}
		else
			this.year = 2019;
		
	}

	/*
	 * This is my getter for month that returns 
	 * an int.
	 */
	public int getMonth() {
		return month;
	}

	/*
	 * This is my setter for month that takes in an
	 * integer. It checks the integer to see if it is within the
	 * numbers one and twelve.
	 *
	 */
	public void setMonth(int month) {
		if(month <= 12 && month >= 1)
		{
			//checking if the month is between 1-12
		this.month = month;
		}
		else
		{
			System.out.println("Not a valid month");
		}
	}

	/*
	 * This is my getter for day that returns
	 * an int.
	 */
	public int getDay() {
		return day;
	}

	/*
	 * This is my setter for day where I check to 
	 * see if the int given is within one and thirty one.
	 */
	public void setDay(int day) 
	{
		if(day <= 31 && day >= 1)
		{
			//checking if the day is between 1-31
		this.day = day;
		}
		else
		{
			System.out.println("Not a valid day");
		}
	}
	
	/*
	 * The equals method checks to see if one date
	 * is equal to another.
	 */
	public boolean equals(Object obj)
	{
		boolean sameDate = false;
		
		if(obj == null)
			return false;
		if(!(obj instanceof Date))
			return false;
		
		Date cast = (Date)obj;
		//Casting the object to a date
	
				//checking if the object is a instance of fate
		if(this.year == cast.year && this.month == cast.month
			&&  this.day == cast.day)
			{
				sameDate = true;
			}

        return sameDate;
	}
	
	/*
	 * The toString method returns a string of 
	 * the year, month and day. 
	 */
	public String toString()
	{
		String retVal = "";
		retVal += "Date: " + this.month + "/" + this.day + "/" + this.year;
		return retVal;
	}
   	
	/*
	 * I decided to make this isGreaterMethod to 
	 * check if one date is greater(has greater priority) over 
	 * the other. I will use this method in my bill class
	 * to compare dates. 
	 */
	public boolean isAfter(Date that)
	{
		boolean greater = false;
		
		if(that != null)
		{
			if(this.year > that.year)
			{
				//If this year is greater than that year
				//then greater is already set to true;
				greater = true;
			}
			 else if(this.year == that.year && this.month > that.month)
		    {
				 //if this year equals that year but this month is greater
				 //than that month
		    	greater = true;
		    }
			 else if( this.year == that.year && this.month == that .month
					 && this.day > that.day)
			 {
				 //Years and months are equal but this day is greater than
				 //that day
				 greater = true;
			 }
			 else if( this.year == that.year && this.month == that.month 
					 &&  this.day == that.day)
				 //Everything is equals
			 {
				 System.out.println("Same date");
			 }
			 else 
				 greater = false;
					 
		}
		return greater;
	}

	/*
	 * The compareTO method is a overidden 
	 * method from implementing comparable.
	 * I compare the year at first, then month and
	 * day. Return 1 if this date is greater than 
	 * "that date". 0 if the same and -1 if less than.
	 */
	@Override
	public int compareTo(Object obj) {
		if(obj == null)
			throw new RuntimeException("Object null");
		//Checking if object is null)
		if(!(obj instanceof Date))
			throw new RuntimeException("Object not Date");
		//Casting object to date
		Date that = (Date) obj;
		if(this.year == that.year && this.month == that.month && this.day== that.day)
		        return 0;
		else if(this.isAfter(that))
			return -1;
		else return  1;
			
	}
}
